import FastFoodApp from './FastFoodApp';
export default FastFoodApp;
