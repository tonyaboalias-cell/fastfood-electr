import React, { useEffect, useState } from "react";
import { Rnd } from "react-rnd";

const translations = {
  ar: {
    order: "طلب رقم",
    status: "حالة الطلب",
    items: "العناصر في الطلب",
    ready: "جاهز للاستلام",
    preparing: "قيد التحضير",
    received: "تم الاستلام",
    toggle: "تبديل الحالة",
    reload: "إعادة تشغيل العرض",
    customerScreen: "شاشة عرض العميل",
    employeeScreen: "واجهة الموظف",
    addOrder: "إضافة طلب جديد",
    changeLang: "تغيير اللغة",
  },
  tr: {
    order: "Sipariş No",
    status: "Sipariş Durumu",
    items: "Sipariş Öğeleri",
    ready: "Teslim İçin Hazır",
    preparing: "Hazırlanıyor",
    received: "Teslim Alındı",
    toggle: "Durum Değiştir",
    reload: "Görünümü Yenile",
    customerScreen: "Müşteri Ekranı",
    employeeScreen: "Çalışan Ekranı",
    addOrder: "Yeni Sipariş Ekle",
    changeLang: "Dili Değiştir",
  },
  en: {
    order: "Order #",
    status: "Order Status",
    items: "Items in Order",
    ready: "Ready for Pickup",
    preparing: "Preparing",
    received: "Received",
    toggle: "Toggle Status",
    reload: "Reload View",
    customerScreen: "Customer Display",
    employeeScreen: "Employee Panel",
    addOrder: "Add New Order",
    changeLang: "Change Language",
  },
};

const loadLayout = (key, fallback) => {
  try {
    const saved = localStorage.getItem(key);
    if (!saved) return fallback;
    const parsed = JSON.parse(saved);
    return {
      x: Number(parsed.x ?? fallback.x),
      y: Number(parsed.y ?? fallback.y),
      width: Number(parsed.width ?? fallback.width),
      height: Number(parsed.height ?? fallback.height),
    };
  } catch {
    return fallback;
  }
};

const saveLayout = (key, value) => {
  localStorage.setItem(key, JSON.stringify(value));
};

export default function FastFoodApp() {
  const [lang, setLang] = useState("ar");
  const t = translations[lang];

  const [orders, setOrders] = useState([
    { number: 1, image: "https://via.placeholder.com/600x400?text=Order+1", items: ["برجر", "بطاطا"], status: "preparing" },
  ]);
  const [activeOrder, setActiveOrder] = useState(null);
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    if (orders.length && !activeOrder) setActiveOrder(orders[0]);
  }, [orders, activeOrder]);

  const [customerLayout, setCustomerLayout] = useState(() => loadLayout("customerLayout", { x: 20, y: 20, width: 400, height: 400 }));
  const [employeeLayout, setEmployeeLayout] = useState(() => loadLayout("employeeLayout", { x: 450, y: 50, width: 450, height: 500 }));

  useEffect(() => {
    saveLayout("customerLayout", customerLayout);
  }, [customerLayout]);

  useEffect(() => {
    saveLayout("employeeLayout", employeeLayout);
  }, [employeeLayout]);

  const switchLang = (lng) => {
    setLang(lng);
  };

  const addOrder = () => {
    const newNum = orders.length + 1;
    const newOrder = {
      number: newNum,
      image: `https://via.placeholder.com/600x400?text=Order+${newNum}`,
      items: ["Meal " + newNum, "Drink"],
      status: "preparing",
    };
    setOrders((prev) => [...prev, newOrder]);
    setActiveOrder(newOrder);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 via-gray-800 to-gray-700 text-white p-6 overflow-hidden">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">🍔 FastFood App</h1>
        <div className="flex gap-2">
          <button onClick={() => switchLang("ar")} className="px-3 py-1 rounded bg-white/10 hover:bg-white/20">عربي</button>
          <button onClick={() => switchLang("tr")} className="px-3 py-1 rounded bg-white/10 hover:bg-white/20">Türkçe</button>
          <button onClick={() => switchLang("en")} className="px-3 py-1 rounded bg-white/10 hover:bg-white/20">English</button>
        </div>
      </div>

      <div className="relative w-full h-[80vh]">

        <Rnd
          size={{ width: customerLayout.width, height: customerLayout.height }}
          position={{ x: customerLayout.x, y: customerLayout.y }}
          onDragStop={(e, d) => setCustomerLayout((l) => ({ ...l, x: d.x, y: d.y }))}
          onResizeStop={(e, direction, ref, delta, pos) =>
            setCustomerLayout({ width: ref.offsetWidth, height: ref.offsetHeight, x: pos.x, y: pos.y })
          }
          bounds="parent"
          className="rounded-2xl shadow-2xl overflow-hidden bg-black/40 backdrop-blur-sm border border-white/10"
        >
          <h2 className="text-center text-xl font-semibold py-3 border-b border-white/10">{t.customerScreen}</h2>
          <div className="p-6 flex flex-col items-center gap-4">
            {activeOrder && (
              <>
                <img
                  src={activeOrder.image}
                  alt={`Order ${activeOrder.number}`}
                  className={`w-full max-h-52 object-cover rounded-lg transition-all duration-700 ${visible ? "opacity-100" : "opacity-50"}`}
                />
                <h3 className="text-2xl font-bold">
                  {t.order} <span className="text-yellow-300">{activeOrder.number}</span>
                </h3>
                <div className="text-md">
                  {t.status}: <span className="font-semibold">{t[activeOrder.status]}</span>
                </div>
                <ul className="list-disc list-inside">
                  {activeOrder.items.map((it, idx) => (
                    <li key={idx}>{it}</li>
                  ))}
                </ul>
              </>
            )}
          </div>
        </Rnd>

        <Rnd
          size={{ width: employeeLayout.width, height: employeeLayout.height }}
          position={{ x: employeeLayout.x, y: employeeLayout.y }}
          onDragStop={(e, d) => setEmployeeLayout((l) => ({ ...l, x: d.x, y: d.y }))}
          onResizeStop={(e, direction, ref, delta, pos) =>
            setEmployeeLayout({ width: ref.offsetWidth, height: ref.offsetHeight, x: pos.x, y: pos.y })
          }
          bounds="parent"
          className="rounded-2xl shadow-2xl overflow-hidden bg-black/40 backdrop-blur-sm border border-white/10"
        >
          <h2 className="text-center text-xl font-semibold py-3 border-b border-white/10">{t.employeeScreen}</h2>
          <div className="p-6 flex flex-col gap-4 overflow-y-auto h-[calc(100%-60px)]">
            <button onClick={addOrder} className="px-4 py-2 rounded bg-green-600 hover:bg-green-500">➕ {t.addOrder}</button>
            <div className="space-y-3">
              {orders.map((o) => (
                <div
                  key={o.number}
                  className={`p-3 rounded-lg border ${activeOrder?.number === o.number ? "border-yellow-400" : "border-white/20"} bg-white/5 flex justify-between items-center`}
                >
                  <div>
                    <div className="font-bold">{t.order} {o.number}</div>
                    <div className="text-sm text-gray-300">{t[o.status]}</div>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => {
                        setOrders((old) =>
                          old.map((ord) =>
                            ord.number === o.number
                              ? { ...ord, status: ord.status === "ready" ? "received" : ord.status === "preparing" ? "ready" : "preparing" }
                              : ord
                          )
                        );
                        setActiveOrder(o);
                      }}
                      className="px-3 py-1 bg-blue-600 rounded hover:bg-blue-500"
                    >
                      {t.toggle}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Rnd>

      </div>
    </div>
  );
}
