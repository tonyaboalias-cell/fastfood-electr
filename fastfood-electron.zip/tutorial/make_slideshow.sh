#!/usr/bin/env bash
DURATION_PER_SLIDE=8
ffmpeg -y -framerate 1/$DURATION_PER_SLIDE -i tutorial/slides/slide%02d.png -c:v libx264 -r 30 -pix_fmt yuv420p tutorial_slideshow.mp4
