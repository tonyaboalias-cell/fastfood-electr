# Tutorial script (Full narration + actions)
... (see README or tutorial-script.md in the archive)
