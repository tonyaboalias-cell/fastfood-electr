# FastFood Electron App (React)

This repository contains a demo React app (FastFood display + employee panel) and an Electron wrapper with scripts to run and to build a distributable. It also includes a detailed tutorial script and slide images so you can produce a tutorial video quickly.

See tutorial/ for slides and a full script.
